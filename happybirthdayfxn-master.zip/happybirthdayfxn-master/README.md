<p align="center">
    <img width="100" height="100" src="https://pic.tyzhang.top/images/2022/06/11/icon.png" alt="logo">
</p>

# happybirthdayfxn

### 一个HTML动态网页生日贺卡，送给好朋友的生日礼物.

### 🎉 演示地址

[Happy Birthday](https://ztygalaxy.github.io/happybirthdayfxn/)， 或者扫描下方二维码。

Tips：由于浏览器限制，部分浏览器无法播放 BGM。

<img src="https://pic.tyzhang.top/images/2022/06/11/qcode.png" style="zoom:33%;" />

### 🔨 快速开始

如果你对 `HTML` 很熟悉，打开便知详情。

在 `app.css` 中修改 `你的页数 * 100%`。

### 🎤 其他

首次提交：`2017-03-27`

最新提交：`2022-06-11`

记得给我一颗star，有问题可以[邮件](mailto:zhangty1996@163.com)给我。